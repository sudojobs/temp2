print("Xgent Agentic AI Lite Edition Running - This is Option A (No Models bundled)")
print("Place GGUF model inside models/ directory to enable llama_cpp backend")
